<?php
get_template_part('module/10');

?>


<?php wp_footer(); ?>

</body>
<!--end body-->

</html>
<!--end html -->