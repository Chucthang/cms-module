$(document).ready(function() {

    $('#ragne_dotone').slider({
        range: true,
        min: 10,
        max: 100,
        values: [10, 100],

    });


});