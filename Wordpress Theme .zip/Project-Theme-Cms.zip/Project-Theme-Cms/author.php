<?php get_header();?>

 
<div class="content">

        <section id="main-content">

                <div class="author-box">
                <?php get_template_part('author-bio'); ?>
                    <?php
                
                // Hiển thị avatar của tác giả
                echo '<div class="author-avatar">'. get_avatar( get_the_author_meta( 'ID' ) ) . '</div>';
        
                // hiển thị tên tác giả
                printf( '<h3>'. __( 'Posts by %1$s', 'Hayghe' ) . '</h3>', get_the_author() );
        
                // Hiển thị giới thiệu của tác giả
                echo '<p>'. get_the_author_meta( 'description' ) . '</p>';
        
                // Hiển thị field website của tác giả
                if ( get_the_author_meta( 'user_url' ) ) : printf( __('<a href="%1$s" title="Visit to %2$s website">Visit to my website</a>', 'thachpham'),
                        get_the_author_meta( 'user_url' ), get_the_author() );
                endif;
                     ?>
        </div>
        <?php if ( is_tag() || is_category() ) : ?>
        <div class="archive-description">
                <?php echo term_description(); ?>
        </div>
        <?php endif; ?>

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <?php get_template_part('content', get_post_format()); ?>
        <?php endwhile; ?>
        <?php hayghe_pagination(); ?>
        <?php else : ?>
                <?php get_template_part('content', 'none'); ?>
        <?php endif; ?>
        </section>
        <section id="sidebar">
 
        </section>
 
</div>

<?php get_footer(); ?>