<div class="type-5-cms">
    <div class="container">
        <div class="row">
            <div class="col-md-4 ">
                <div class="name-img">
                    <h3>WEDDING DECOR</h3>
                </div>
                <div class="img-weeding">
                    <div class="img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module5/h1.jpg" alt="">
                        </a>
                    </div>

                </div>
                <div class="info">
                    <p>Thank you for choosing Cosmo Theme and purchasing one of our Premium WordPress Themes. Your choice is highly appreciated!</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="name-img">
                    <h3>BRIDE & GROOM</h3>
                </div>
                <div class="img-weeding">
                    <div class="img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module5/h2.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="info">
                    <p>Thank you for choosing Cosmo Theme and purchasing one of our Premium WordPress Themes. Your choice is highly appreciated!</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="name-img">
                    <h3>THE PROPOSE</h3>
                </div>
                <div class="img-weeding">
                    <div class="img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module5/h3.jpg" alt="">
                        </a>
                    </div>
                </div>
                <div class="info">
                    <p>Thank you for choosing Cosmo Theme and purchasing one of our Premium WordPress Themes. Your choice is highly appreciated!</p>
                </div>
            </div>
        </div>
    </div>
</div>