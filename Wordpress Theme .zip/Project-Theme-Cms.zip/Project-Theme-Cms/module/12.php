<div class="type-12">
    <div class="timeplate">
        <div class="container">
            <div class="title-13"></div>
            <h3 class="title_ourstory">CATEGORY: BLOG</h3>
        </div>
    </div>
    <div class="container">
        <div class="blog-img">
            <img src="<?php bloginfo("template_directory"); ?>/images/module12/post.jpg" alt="img-post">
        </div>
        <h2 class="title-post">
            <a href="#">IMAGE POST</a>
        </h2>
        <div class="blog_meta">
            <span class="tzblog_date">
                February 9, 2015 /
            </span>
            <span class="tzblog_comments">
                <a href="#">Leave a comment</a> </span>
            <span class="tztags_link">
                /<a href="#" rel="tag">love</a>,<a href="#" rel="tag">songs</a>/ </span>
            <span class="tzcat_link">
                <a href="#" rel="category tag">Blog</a> </span>
        </div>
        <div class="tzthe_content">
            <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly. North Texas Wedding Photographer Rachel Meagan Photography 25.<br>
                Destination wedding photography – bring a photographer or use a local one? Wedding photography is the photography of activities relating to weddings. It encompasses photographs of the couple before marriage </p>
            <a class="more-link" href="#">READ MORE</a>
        </div>
    </div>
    <div class="container">
        <div class="music">
            <a href="#"> <img src="<?php bloginfo("template_directory"); ?>/images/module12/missic.jpg" alt="music"></a>
        </div>
    </div>
    <div class="container">

        <h2 class="title-post">
            <a href="#">IMAGE POST</a>
        </h2>
        <div class="blog_meta">
            <span class="tzblog_date">
                February 9, 2015 /
            </span>
            <span class="tzblog_comments">
                <a href="#">Leave a comment</a> </span>
            <span class="tztags_link">
                /<a href="#" rel="tag">love</a>,<a href="#" rel="tag">songs</a>/ </span>
            <span class="tzcat_link">
                <a href="#" rel="category tag">Blog</a> </span>
        </div>
        <div class="tzthe_content">
            <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly. North Texas Wedding Photographer Rachel Meagan Photography 25.<br>
                Destination wedding photography – bring a photographer or use a local one? Wedding photography is the photography of activities relating to weddings. It encompasses photographs of the couple before marriage </p>
            <a class="more-link" href="#">READ MORE</a>
        </div>
        <div class="video">
            <div class="abg">
                <video width="100%" controls>
                    <source width="100%" src="<?php bloginfo("template_directory"); ?>/images/module12/video.mp4" type="video/mp4">
                </video>
            </div>
            <button class="tzautoplay" style="display: inline-block;"><i class="fa fa-video-camera"></i></button>
        </div>



        <h2 class="title-post">
            <a href="#">VIDEO POST</a>
        </h2>
        <div class="blog_meta">
            <span class="tzblog_date">
                February 9, 2015 /
            </span>
            <span class="tzblog_comments">
                <a href="#">Leave a comment</a> </span>
            <span class="tztags_link">
                /<a href="#" rel="tag">love</a>,<a href="#" rel="tag">songs</a>/ </span>
            <span class="tzcat_link">
                <a href="#" rel="category tag">Blog</a> </span>
        </div>
        <div class="tzthe_content">
            <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly. North Texas Wedding Photographer Rachel Meagan Photography 25.<br>
                Destination wedding photography – bring a photographer or use a local one? Wedding photography is the photography of activities relating to weddings. It encompasses photographs of the couple before marriage </p>
            <a class="more-link" href="#">READ MORE</a>
        </div>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="<?php bloginfo("template_directory"); ?>/images/module12/video1.jpg" alt=""></div>
                <div class="swiper-slide"><img src="<?php bloginfo("template_directory"); ?>/images/module12/video2.jpg" alt=""></div>

            </div>
            <!-- Add Arrows -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <h2 class="title-post">
            <a href="#">VIDEO POST</a>
        </h2>
        <div class="blog_meta">
            <span class="tzblog_date">
                February 9, 2015 /
            </span>
            <span class="tzblog_comments">
                <a href="#">Leave a comment</a> </span>
            <span class="tztags_link">
                /<a href="#" rel="tag">love</a>,<a href="#" rel="tag">songs</a>/ </span>
            <span class="tzcat_link">
                <a href="#" rel="category tag">Blog</a> </span>
        </div>
        <div class="tzthe_content">
            <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly. North Texas Wedding Photographer Rachel Meagan Photography 25.<br>
                Destination wedding photography – bring a photographer or use a local one? Wedding photography is the photography of activities relating to weddings. It encompasses photographs of the couple before marriage </p>
            <a class="more-link" href="#">READ MORE</a>
        </div>
        <div class="tzquote tzblog-format">
            <i class="fa fa-heart-o quote_icon"></i>
            <p>
                <i class="fa fa-quote-left"></i>
                Better to have loved and lost, than to have never loved at all. <i class="fa fa-quote-right"></i>
            </p>
            <span class="author_quote">
                ~ ST.AUGUSTINE ~ </span>
        </div>
        <h2 class="title-post">
            <a href="#">QUOTE POST</a>
        </h2>
        <div class="blog_meta">
            <span class="tzblog_date">
                February 9, 2015 /
            </span>
            <span class="tzblog_comments">
                <a href="#">Leave a comment</a> </span>
            <span class="tztags_link">
                /<a href="#" rel="tag">love</a>,<a href="#" rel="tag">songs</a>/ </span>
            <span class="tzcat_link">
                <a href="#" rel="category tag">Blog</a> </span>
        </div>
        <div class="tzthe_content">
            <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly. North Texas Wedding Photographer Rachel Meagan Photography 25.<br>
                Destination wedding photography – bring a photographer or use a local one? Wedding photography is the photography of activities relating to weddings. It encompasses photographs of the couple before marriage </p>
            <a class="more-link" href="#">READ MORE</a>
        </div>

    </div>


</div>