<div class="type-2">

    <div class="wrap_slider">
        <div class="swiper-container ">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="slide_2" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/1.jpg') ">
                        <div class="container changeContain">
                            <div class="text1">
                                <div class="block1"> SELINA </div>
                                <div class="block2"> JACOS </div>
                                <div class="block3"> & </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slide_2" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/2.jpg') ">
                        <div class="container margincontain">
                            <div class="form_animate ">
                                <div class="form-one">
                                    <div class="name_bride">
                                        <p id="text_animate">MICHAEL AND JONNY </p>
                                        <h3 id="display_txtct" class="hname"></h3>
                                    </div>
                                    <div class="content_bride">
                                        <p class="p1">Thank you for choosing CosmoThemes and purchasing one of our Premium </p>
                                        <p class="p2">WordPress Themes your choice is greatly appreciated! </p>
                                        <p class="month"> 12TH NOVEMBER, 2014 IN GUSH GARDEN </p>
                                    </div>
                                    <div class="btn_height">
                                        <span class="btn_bride"> JOIN THE EVENT </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slide_2" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/3.jpg') ">


                        <span class="spananimate text_im1"> Jenny </span>
                        <i class="fa fa-heart spananimate "></i>
                        <span class="spananimate text_im2"> mar </span>



                    </div>
                </div>

            </div>
        </div>

        <div class="nextprev">
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <!-- Add Arrows -->


</div>