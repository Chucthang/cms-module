<div class="type-3">
    <div class="container">
        <div class="tong">
            <div class="row">
                <div class="col-md-4">
                    <div class="left">
                        <div class="heart">
                            <i class="far fa-heart icon"></i>
                        </div>
                        <div class="text">
                            COUNTDOWN TO
                            <br>
                            <span>MICHAEL &amp; JOHNNY</span>
                            <br>
                            WEDDING CEREMONY
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="right">
                        <div class="row">
                            <div class="col-md-3 ex">
                                <div class="a">
                                    <span>00</span>
                                    <p>DAYS</p>
                                </div>
                            </div>
                            <div class="col-md-3 ex">
                                <div class="a">
                                    <span>00</span>
                                    <p>HOURS</p>
                                </div>
                            </div>
                            <div class="col-md-3 ex">
                                <div class="a">
                                    <span>00</span>
                                    <p>MINUTES</p>
                                </div>
                            </div>
                            <div class="col-md-3 ex">
                                <div class="a">
                                    <span>00</span>
                                    <p>SECONDS</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>