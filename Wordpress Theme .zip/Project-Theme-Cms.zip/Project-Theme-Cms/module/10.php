<div class="type-10">
    <div class="container">
        <div class="row">
            <!-- cot1 -->
            <div class="col-md-4">
                <h3 class="tieude"><span>LOCATION</span></h3>
                <div class="cot1">
                    <address>London, UK, 10, Friks, Avenue</address>
                    <span>+987 092 291 091</span>
                    <div class="email">support@templaza.com</div>
                </div>
            </div>

            <!-- cot2 -->
            <div class="col-md-4">
                <div class="img"> <img src="<?php bloginfo("template_directory"); ?>/images/module10/10.png" alt="Everline"></div>
                <p>All Rights Reserved. Copyright @ TemPlaza</p>
            </div>

            <!-- cot3 -->
            <div class="col-md-4">
                <h3 class="tieude2">
                    <span>GET IN TOUCH</span>
                </h3>
                <div class="cot3">
                    <span><a href="#"><i class="fa fa-facebook"></i></a></span>
                    <span><a href="#"><i class="fa fa-google-plus"></i></a></span>
                    <span><a href="#"><i class="fa fa-twitter"></i></a></span>
                    <span><a href="#"><i class="fa fa-youtube"></i></a></span>
                </div>
            </div>
        </div>
    </div>
</div>