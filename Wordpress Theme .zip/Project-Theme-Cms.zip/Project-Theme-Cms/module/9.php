<div class="type-9-cms">
    <div class="container">
        <h2 class="title">
            FROM OUR BLOG
        </h2>
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="blog-item">
                    <div class="blog-img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module9/h4.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-description">
                        <h3>
                            <a class="title2" href="#">Nulla facilisis vitae</a>
                        </h3>
                        <span class="date">
                            February 5, 2015/a <a href="#">Leave a comment</a>
                        </span>
                        <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly.</p>
                        <a class="blog-readmore" href="#">readmore</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="blog-item">
                    <div class="blog-img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module9/h5.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-description">
                        <h3>
                            <a class="title2" href="#">Mauris viverra ipsum</a>
                        </h3>
                        <span class="date">
                            February 5, 2015/a <a href="#">Leave a comment</a>
                        </span>
                        <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly.</p>
                        <a class="blog-readmore" href="#">readmore</a>
                    </div>
                </div>

            </div>
            <div class="col-md-3 col-sm-6">
                <div class="blog-item">
                    <div class="blog-img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module9/h6.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-description">
                        <h3>
                            <a class="title2" href="#">YOUR HONEYMOON</a>
                        </h3>
                        <span class="date">
                            February 5, 2015/a <a href="#">Leave a comment</a>
                        </span>
                        <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly.</p>
                        <a class="blog-readmore" href="#">readmore</a>
                    </div>
                </div>

            </div>
            <div class="col-md-3 col-sm-6">
                <div class="blog-item">
                    <div class="blog-img">
                        <a href="#">
                            <img src="<?php bloginfo("template_directory"); ?>/images/module9/h7.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-description">
                        <h3>
                            <a class="title2" href="#">PLAN YOUR TRIP</a>
                        </h3>
                        <span class="date">
                            February 5, 2015/a <a href="#">Leave a comment</a>
                        </span>
                        <p>Thank you for choosing CosmoThemes and purchasing one of our Premium WordPress Themes your choice is greatly.</p>
                        <a class="blog-readmore" href="#">readmore</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>