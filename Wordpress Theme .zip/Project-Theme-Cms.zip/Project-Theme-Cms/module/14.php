<div class="type-14">

    <!-- tieude -->
    <div class="tieude">

        <h1 class="fullwidth">FULLWIDTH</h1>

    </div>
    <!-- hinh -->
    <div class="img">
        <!-- dong1 -->
        <div class="row">
            <!-- cot1 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img1.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">James &#038; Miley</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- cot2 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img12.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">Aliquam &#038; Miley</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- cot3 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img3.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">Reader &#038; Mauris</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- close dong1 -->
        <!-- dong2 -->
        <div class="row">
            <!-- cot1 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img4.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">Donec &#038; Lacus</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- cot2 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img5.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">Efficitur &#038;Lacus</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- cot3 -->
            <div class="col-md-4">
                <div class="container1">
                    <img src="<?php bloginfo("template_directory"); ?>/images/module14/img7.jpg" alt="">
                    <div class="overlay">
                        <div class="note1">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">Praesent &#038; Orci</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    /
                                    <a href="#" rel="tag">NewYork</a>,
                                    <a href="#" rel="tag">USA</a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- close dong2 -->

    </div>

</div>