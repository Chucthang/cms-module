<div class="type-8">
    <!-- <div class="container"> -->
    <div class="col-sm-12">
        <div class="custom">
            <div class="wrapper">
                <div class="tz-video">
                    <div class="tz-video-content">
                        <button class="autoplay"><i class="fa fa-video-camera"></i></button>
                        <button class="pause"><i class="fa fa-pause"></i></button>
                        <h3>“The Power of Love”</h3>
                        <p>JENNIFER AND JAMES WEDDING VIDEO</p>
                    </div>
                    <div class="bg-video"></div>
                    <video class="videoID" style="margin-top: -379.406px;">
                        <source type="video/mp4" src="<?php bloginfo("template_directory"); ?>/images/module8/v1.mp4">
                        <source type="video/ogg" src="<?php bloginfo("template_directory"); ?>/images/module8/v2.ogv">
                        <source type="video/webm" src="<?php bloginfo("template_directory"); ?>/images/module8/v3.webm">
                    </video>
                </div>
            </div>
        </div>
    </div>
    <!-- </div> -->
</div>