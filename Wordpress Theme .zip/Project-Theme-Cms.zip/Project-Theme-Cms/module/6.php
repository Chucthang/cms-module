<div class="type-6">
    <div class="row">
        <div class=" col-md-4 col-sm-6 ">
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por1.jpg" alt="sed1">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">PRAESENT & ORCI</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por4.jpg" alt="sed2">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">READER & MAURIS</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class=" col-md-4 col-sm-6 ">
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por2.jpg" alt="sed4">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">EFFICITUR & LACUS</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por3.jpg" alt="sed3">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">ALIQUAM & MILEY</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class=" col-md-4 col-sm-6 ">
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por5.jpg" alt="sed4">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">FERTUM AC LOREM</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hovereffect">
                <img class="img-responsive" src="<?php bloginfo("template_directory"); ?>/images/module6/por6.jpg" alt="sed5">
                <div class="overlay">
                    <div class="ggg">
                        <div>
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="#">DONEC & LACUS</a></h3>
                            <div class="tzmeta">
                                <span>February 9, 2015</span>
                                <span class="tztag">
                                    <a href="#" rel="tag">NewYork</a>,<a href="#" rel="tag">USA</a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>




</div>