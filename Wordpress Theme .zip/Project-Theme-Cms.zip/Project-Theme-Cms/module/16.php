<div class="type-16">
    <div class="tieude">
        <h1>PORTFOLIO 3 COLUMNS</h1>
    </div>
    <div class="tzPortfolio-wrap">
        <div class="container">
            <!--dong 1-->
            <div class="row">

                <div class="col-md-4">

                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img1.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Sed efficitu</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img2.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Morbi eleifend</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img3.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Quisque nec</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!--close dong1-->
            <!--dong2-->
            <div class="row">

                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img4.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Nulla ac magna</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img5.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Vestibulum varius</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img6.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Purus ut</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!--close dong 2-->
            <!--dong 3-->
            <div class="row">

                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img7.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Nullam aliquam</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img8.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Curabitur euismod in</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="container1">
                        <img src="<?php bloginfo("template_directory"); ?>/images/module16/img9.jpg" alt="">
                        <div class="overlay">
                            <div class="note1">
                                <i class="fa fa-heart-o tzicon"></i>
                                <h3><a href="#">Quisque viverra</a></h3>
                                <div class="tzmeta">
                                    <span>February 9, 2015</span>
                                    <span class="tztag">
                                        /
                                        <a href="#" rel="tag">NewYork</a>,
                                        <a href="#" rel="tag">USA</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--close dong 3-->
</div>
</div>