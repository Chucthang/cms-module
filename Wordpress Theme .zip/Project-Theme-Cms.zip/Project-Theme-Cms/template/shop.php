<?php
/*
 Template Name: shop
 */
get_header('multiple');
get_template_part('module/22');

// get_footer();
