<?php
/*
 Template Name: Trang chủ
 */
get_header(); // Header
get_template_part('module/2');

get_template_part('module/3');
if (is_active_sidebar('module-4')) {
    dynamic_sidebar('module-4');
} else {
    _e('This is widget area. Go to Appearance -> Widgets to add some widgets.', 'hayghe');
}
get_template_part('module/5');
get_template_part('module/6');
get_template_part('module/7');
get_template_part('module/8');
get_template_part('module/9');

?>

<?php
get_footer();  // Footer
