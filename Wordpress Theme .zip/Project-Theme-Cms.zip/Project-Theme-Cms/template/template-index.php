<?php
/*
 Template Name: Trang chủ
 */
get_header(); // Header
get_template_part('module/2');

get_template_part('module/3');
get_template_part('module/4');
get_template_part('module/5');
get_template_part('module/6');
get_template_part('module/7');
get_template_part('module/8');
get_template_part('module/9');

?>

<?php
get_footer();  // Footer
