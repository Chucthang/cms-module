<?php
/*
 Template Name: Contact
 */
//  get_header(); 
 ?>
 <?php   get_template_part('module/15', 'Module');  ?>

<?php 
//  get_footer();  // Footer