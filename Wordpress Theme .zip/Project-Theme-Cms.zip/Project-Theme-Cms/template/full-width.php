<?php
/*
 Template Name: Full Width
 */
get_header('multiple');
get_template_part('module/14');
get_footer();  // Footer
