<?php
/*
 Template Name: Portfolio left sidebar
 */
get_header('multiple');
get_template_part('module/18');
get_footer();  // Footer
