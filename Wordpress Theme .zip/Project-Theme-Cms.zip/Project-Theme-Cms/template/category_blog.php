<?php
/*
 Template Name: Category blog
 */
get_header('multiple');
get_template_part('module/12');
get_footer();  // Footer
