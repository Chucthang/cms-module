<?php
/*
 Template Name: PortFolio 2 Column
 */
get_header('multiple');
get_template_part('module/15');
get_footer();  // Footer
